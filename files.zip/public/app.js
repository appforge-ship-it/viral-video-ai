class NovaVideoAI {
    constructor() {
        this.prompt = '';
        this.sceneCount = 4;
        this.fps = 24;
        this.scenes = [];
        this.currentVideo = null;
        this.previousVideos = [];
        this.isPlaying = false;
        this.currentSceneIndex = 0;

        this.initElements();
        this.attachEventListeners();
        this.loadFromStorage();
    }

    initElements() {
        this.promptInput = document.getElementById('promptInput');
        this.sceneSlider = document.getElementById('sceneSlider');
        this.sceneValue = document.getElementById('sceneValue');
        this.expandButton = document.getElementById('expandButton');
        this.fpsSlider = document.getElementById('fpsSlider');
        this.fpsValue = document.getElementById('fpsValue');
        this.generateButton = document.getElementById('generateButton');
        this.scenesContainer = document.getElementById('scenesContainer');
        this.loadingState = document.getElementById('loadingState');
        this.errorState = document.getElementById('errorState');
        this.errorMessage = document.getElementById('errorMessage');
        this.videoPreview = document.getElementById('videoPreview');
        this.emptyState = document.getElementById('emptyState');
        this.videoTitle = document.getElementById('videoTitle');
        this.previewSceneCount = document.getElementById('previewSceneCount');
        this.previewFps = document.getElementById('previewFps');
        this.scenesPreviewContainer = document.getElementById('scenesPreviewContainer');
        this.playBtn = document.getElementById('playBtn');
        this.pauseBtn = document.getElementById('pauseBtn');
        this.progressFill = document.getElementById('progressFill');
        this.progressBar = document.querySelector('.progress-bar');
        this.timeDisplay = document.getElementById('timeDisplay');
        this.previousVideosList = document.getElementById('previousVideos');
    }

    attachEventListeners() {
        this.sceneSlider.addEventListener('input', (e) => {
            this.sceneCount = parseInt(e.target.value);
            this.sceneValue.textContent = this.sceneCount;
        });

        this.fpsSlider.addEventListener('input', (e) => {
            this.fps = parseInt(e.target.value);
            this.fpsValue.textContent = this.fps;
        });

        this.expandButton.addEventListener('click', () => this.expandScenes());
        this.generateButton.addEventListener('click', () => this.generateVideo());
        this.playBtn.addEventListener('click', () => this.play());
        this.pauseBtn.addEventListener('click', () => this.pause());
        this.progressBar.addEventListener('click', (e) => this.seek(e));
    }

    expandScenes() {
        const userPrompt = this.promptInput.value.trim();

        if (!userPrompt) {
            this.showError('Please enter a video concept first');
            return;
        }

        this.scenes = this.generateScenePrompts(userPrompt, this.sceneCount);
        this.renderSceneInputs();
    }

    generateScenePrompts(mainIdea, count) {
        const scenes = [];
        const keywords = this.extractKeywords(mainIdea);

        for (let i = 0; i < count; i++) {
            const progressRatio = i / (count - 1 || 1);
            let scenePrompt = '';

            if (count === 1) {
                scenePrompt = mainIdea;
            } else if (i === 0) {
                scenePrompt = `Opening scene: ${mainIdea}. Establish the setting and main subject.`;
            } else if (i === count - 1) {
                scenePrompt = `Closing scene: ${mainIdea}. Dramatic conclusion with all elements highlighted.`;
            } else {
                const midKeyword = keywords[Math.floor(i % keywords.length)] || 'action';
                scenePrompt = `Scene ${i}: ${mainIdea}. Focus on ${midKeyword} and dynamic movement.`;
            }

            scenes.push({
                scene: i + 1,
                text: scenePrompt,
                duration: 3
            });
        }

        return scenes;
    }

    extractKeywords(text) {
        const stopWords = new Set([
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'is', 'was', 'are',
            'from', 'by', 'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may',
            'that', 'this', 'it', 'its', 'as', 'if', 'while', 'where', 'what', 'which', 'who'
        ]);

        const words = text.toLowerCase().split(/\s+/);
        const keywords = words
            .filter(w => !stopWords.has(w) && w.length > 3)
            .slice(0, 5);

        return keywords.length > 0 ? keywords : ['scene'];
    }

    renderSceneInputs() {
        this.scenesContainer.innerHTML = '';

        this.scenes.forEach((scene, index) => {
            const sceneGroup = document.createElement('div');
            sceneGroup.className = 'scene-input-group';

            const sceneNumber = document.createElement('div');
            sceneNumber.className = 'scene-number';
            sceneNumber.textContent = scene.scene;

            const sceneInput = document.createElement('textarea');
            sceneInput.className = 'scene-input';
            sceneInput.value = scene.text;
            sceneInput.addEventListener('input', (e) => {
                this.scenes[index].text = e.target.value;
            });

            sceneGroup.appendChild(sceneNumber);
            sceneGroup.appendChild(sceneInput);
            this.scenesContainer.appendChild(sceneGroup);
        });
    }

    async generateVideo() {
        const userPrompt = this.promptInput.value.trim();

        if (!userPrompt) {
            this.showError('Please enter a video concept');
            return;
        }

        if (this.scenes.length === 0) {
            this.showError('Please expand scenes first');
            return;
        }

        this.showLoading(true);
        this.hideError();

        try {
            const response = await fetch('/api/generate-script', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    prompt: userPrompt,
                    sceneCount: this.sceneCount
                })
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.error || 'Failed to generate video script');
            }

            const data = await response.json();

            this.currentVideo = {
                title: this.generateVideoTitle(userPrompt),
                prompt: userPrompt,
                script: data.script,
                scenes: data.scenes || this.scenes,
                fps: this.fps,
                sceneCount: this.sceneCount,
                timestamp: new Date().toLocaleString()
            };

            this.scenes = this.currentVideo.scenes;
            this.displayVideoPreview();
            this.addToPreviousVideos();
            this.hideError();
        } catch (error) {
            console.error('Error:', error);
            this.showError(error.message);
        } finally {
            this.showLoading(false);
        }
    }

    generateVideoTitle(prompt) {
        const words = prompt.split(' ').slice(0, 5).join(' ');
        return words.length > 50 ? words.substring(0, 50) + '...' : words;
    }

    displayVideoPreview() {
        this.emptyState.classList.add('hidden');
        this.videoPreview.classList.remove('hidden');

        this.videoTitle.textContent = this.currentVideo.title;
        this.previewSceneCount.textContent = this.currentVideo.sceneCount;
        this.previewFps.textContent = this.currentVideo.fps;

        this.renderScenePreviews();
        this.updateTimeDisplay();
    }

    renderScenePreviews() {
        this.scenesPreviewContainer.innerHTML = '';

        this.currentVideo.scenes.forEach((scene, index) => {
            const sceneItem = document.createElement('div');
            sceneItem.className = 'scene-preview-item';
            sceneItem.addEventListener('click', () => {
                this.currentSceneIndex = index;
                this.updateScenePreview();
            });

            const imageDiv = document.createElement('div');
            imageDiv.className = 'scene-preview-image';
            const emoji = this.getEmojiForScene(scene.text);
            imageDiv.textContent = emoji;

            const textDiv = document.createElement('div');
            textDiv.className = 'scene-preview-text';
            textDiv.textContent = scene.text;

            const numberDiv = document.createElement('div');
            numberDiv.className = 'scene-preview-number';
            numberDiv.textContent = scene.scene;

            sceneItem.appendChild(imageDiv);
            sceneItem.appendChild(numberDiv);
            sceneItem.appendChild(textDiv);

            this.scenesPreviewContainer.appendChild(sceneItem);
        });
    }

    getEmojiForScene(text) {
        const text_lower = text.toLowerCase();
        const emojiMap = {
            'future': '🚀',
            'space': '🌌',
            'night': '🌙',
            'day': '☀️',
            'water': '💧',
            'fire': '🔥',
            'tech': '🤖',
            'music': '🎵',
            'dance': '💃',
            'action': '⚡',
            'calm': '🧘',
            'happy': '😊',
            'sad': '😢',
            'amazing': '✨',
            'nature': '🌿',
            'city': '🏙️',
            'beach': '🏖️',
            'mountain': '⛰️',
            'sky': '☁️',
            'storm': '⛈️'
        };

        for (const [key, emoji] of Object.entries(emojiMap)) {
            if (text_lower.includes(key)) {
                return emoji;
            }
        }

        return '🎬';
    }

    updateScenePreview() {
        const allItems = this.scenesPreviewContainer.querySelectorAll('.scene-preview-item');
        allItems.forEach((item, index) => {
            if (index === this.currentSceneIndex) {
                item.style.borderColor = 'var(--accent-purple)';
                item.style.boxShadow = '0 8px 20px rgba(102, 126, 234, 0.4)';
            } else {
                item.style.borderColor = 'var(--border-color)';
                item.style.boxShadow = 'none';
            }
        });
    }

    play() {
        this.isPlaying = true;
        this.playBtn.classList.add('active');
        this.pauseBtn.classList.remove('active');
        this.animatePlayback();
    }

    pause() {
        this.isPlaying = false;
        this.playBtn.classList.remove('active');
        this.pauseBtn.classList.add('active');
    }

    animatePlayback() {
        if (!this.isPlaying) return;

        const totalScenes = this.currentVideo.scenes.length;
        const sceneDuration = 3000 / this.currentVideo.fps;
        const totalDuration = totalScenes * sceneDuration;

        let startTime = Date.now();
        let lastSceneIndex = 0;

        const animate = () => {
            if (!this.isPlaying) return;

            const elapsed = Date.now() - startTime;
            const progress = (elapsed % totalDuration) / totalDuration;

            this.progressFill.style.width = (progress * 100) + '%';

            const currentScene = Math.floor(progress * totalScenes);
            if (currentScene !== lastSceneIndex && currentScene < totalScenes) {
                this.currentSceneIndex = currentScene;
                this.updateScenePreview();
                lastSceneIndex = currentScene;
            }

            this.updateTimeDisplay();

            requestAnimationFrame(animate);
        };

        animate();
    }

    seek(e) {
        const rect = this.progressBar.getBoundingClientRect();
        const percent = (e.clientX - rect.left) / rect.width;
        this.progressFill.style.width = (percent * 100) + '%';

        const totalScenes = this.currentVideo.scenes.length;
        this.currentSceneIndex = Math.floor(percent * totalScenes);
        this.updateScenePreview();
        this.updateTimeDisplay();
    }

    updateTimeDisplay() {
        const totalScenes = this.currentVideo.scenes.length;
        const sceneDuration = 3;
        const totalTime = totalScenes * sceneDuration;
        const currentTime = (this.currentSceneIndex + 1) * sceneDuration;

        const formatTime = (seconds) => {
            const mins = Math.floor(seconds / 60);
            const secs = seconds % 60;
            return `${mins}:${secs.toString().padStart(2, '0')}`;
        };

        this.timeDisplay.textContent = `${formatTime(currentTime)} / ${formatTime(totalTime)}`;
    }

    addToPreviousVideos() {
        this.previousVideos.unshift(this.currentVideo);
        if (this.previousVideos.length > 10) {
            this.previousVideos.pop();
        }
        this.saveToStorage();
        this.renderPreviousVideos();
    }

    renderPreviousVideos() {
        this.previousVideosList.innerHTML = '';

        if (this.previousVideos.length === 0) {
            this.previousVideosList.innerHTML = '<p class="placeholder-text">No videos generated yet</p>';
            return;
        }

        this.previousVideos.forEach((video, index) => {
            const item = document.createElement('div');
            item.className = 'previous-video-item';

            const textSpan = document.createElement('span');
            textSpan.className = 'previous-video-text';
            textSpan.textContent = video.title;
            textSpan.addEventListener('click', () => {
                this.currentVideo = video;
                this.sceneCount = video.sceneCount;
                this.fps = video.fps;
                this.scenes = video.scenes;
                this.promptInput.value = video.prompt;
                this.sceneSlider.value = video.sceneCount;
                this.sceneValue.textContent = video.sceneCount;
                this.fpsSlider.value = video.fps;
                this.fpsValue.textContent = video.fps;
                this.displayVideoPreview();
            });

            const timeSpan = document.createElement('span');
            timeSpan.className = 'previous-video-time';
            timeSpan.textContent = video.timestamp;

            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'previous-video-delete';
            deleteBtn.textContent = '✕';
            deleteBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.previousVideos.splice(index, 1);
                this.saveToStorage();
                this.renderPreviousVideos();
            });

            item.appendChild(textSpan);
            item.appendChild(timeSpan);
            item.appendChild(deleteBtn);
            this.previousVideosList.appendChild(item);
        });
    }

    showLoading(show) {
        if (show) {
            this.loadingState.classList.remove('hidden');
            this.generateButton.disabled = true;
            this.expandButton.disabled = true;
        } else {
            this.loadingState.classList.add('hidden');
            this.generateButton.disabled = false;
            this.expandButton.disabled = false;
        }
    }

    showError(message) {
        this.errorMessage.textContent = message;
        this.errorState.classList.remove('hidden');
    }

    hideError() {
        this.errorState.classList.add('hidden');
    }

    saveToStorage() {
        localStorage.setItem('novaVideoAI_previousVideos', JSON.stringify(this.previousVideos));
    }

    loadFromStorage() {
        const saved = localStorage.getItem('novaVideoAI_previousVideos');
        if (saved) {
            try {
                this.previousVideos = JSON.parse(saved);
                this.renderPreviousVideos();
            } catch (e) {
                console.error('Error loading from storage:', e);
            }
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new NovaVideoAI();
});